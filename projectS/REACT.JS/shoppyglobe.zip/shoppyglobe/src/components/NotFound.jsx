// src/components/NotFound.jsx
export default function NotFound() {
  return <div className="p-6 text-center">Page not found</div>
}
