import ProductList from '../components/ProductList'

export default function Home() {
  return <ProductList />
}
