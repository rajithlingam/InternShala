# Student Registration System

This is a simple starter project.

## Files
- index.html
- style.css
- app.js

Happy coding!
